#include <stdio.h>

int main() {
    printf("kokokoff\n");
	return 0;
}
